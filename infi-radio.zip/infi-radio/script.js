let podCount = 0;
function fetchGeneratedAudio(topic, nextpart, podCount) {
    const fetchUrl = nextpart ? `/generate-audio?topic=${topic}&nextpart=true&podCount=${podCount}` : `/generate-audio?topic=${topic}`;
    return fetch(fetchUrl)
        .then(response => response.blob())
        .then(blob => {
            return URL.createObjectURL(blob);
        });
}   
    const adPlayer = document.getElementById('adPlayer');
    const contentPlayer = document.getElementById('contentPlayer');

    let audioURL;

    const hideAdPlayer = () => {
        adPlayer.style.display = 'none';
        adPlayer.src = '';
        contentPlayer.style.display = 'block';
        console.log('Hide Audio player')
    }
    const playWelcome = () => {
        const topic = document.getElementById('topicInput').value;
        fetchGeneratedAudio(topic).then((url) => {
            audioURL = url; // Fetch the generated audio URL
        });
        adPlayer.style.display = 'block';
        adPlayer.src = '/welcome.mp3';
        adPlayer.play();
        console.log('Play welcome')
        adPlayer.addEventListener('ended', playFirstAd);
    };

    const playFirstAd = () => {
        adPlayer.src = '/ads.mp3';
        adPlayer.play();
        console.log('Play first ad')
        adPlayer.addEventListener('ended', playPodCast);
    }
    
    const playAds = () => {
        contentPlayer.style.display = 'none';
        contentPlayer.src = '';
        adPlayer.style.display = 'block';
        adPlayer.src = '/ads.mp3';
        adPlayer.play();
        console.log('Play other ads')
        adPlayer.addEventListener('ended', hideAdPlayer);
    };

    const playPodCast = async () => {
        const topic = document.getElementById('topicInput').value;
        hideAdPlayer();
        if(audioURL){
            debugger;
            contentPlayer.src = audioURL; // Set the audio source
            contentPlayer.play();
            console.log('Play podcast')
            podCount++;
            console.log('podcast count', podCount)
            await fetchGeneratedAudio(topic, true, podCount).then((url) => {
                audioURL = url; // Fetch the generated audio URL
            });
            contentPlayer.addEventListener('ended', function() {
                playAds();
                adPlayer.addEventListener('ended', function() {
                    if(podCount <= 10 && audioURL){
                        playPodCast();
                    }
                });
            });
        }
    };

    const playContinousPodCast = () =>{
        while (podCount <= 10) {
            playPodCast()
        }
    }

    function infiRadio() {
        // play welcome and first ad make call to initial call for the given topic
        playWelcome();
        
        
        // audioPlayer.addEventListener('ended', playPodCast);

        // play the podcast and call for next part of given topic

        // play the next ad 
        // play the next podcast and call for next part of given topic

    }

    document.getElementById('generateAudio').addEventListener('click', infiRadio);
