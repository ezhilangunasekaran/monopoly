import express from 'express';
import path, { dirname } from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import fs from 'fs';
import { OpenAI } from 'openai';

dotenv.config();

const app = express();
const port = 3000;

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

app.use(express.static(__dirname));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Endpoint to generate audio
app.get('/generate-audio', async (req, res) => {
  try {
    // Get the topic from the query parameter
    const topic = req.query.topic || "Any Topic"; // Use a default topic if not provided
    const nextpart = req.query.nextpart
    const podCount = req.query.podCount
    const prompt = nextpart ? `Write a 50 words related news about ${topic}.`: `Write a 50 words intro about ${topic}.`;
    console.log('prompt',prompt)
    const completion = await openai.chat.completions.create({
      messages: [
        { "role": "system", "content": "You are a knowledgeable assistant." },
        { "role": "user", "content":  prompt } // Use the topic in the user's message
      ],
      model: "gpt-3.5-turbo",
    });

    const textToConvert = completion.choices[0].message.content;

    const mp3 = await openai.audio.speech.create({
      model: "tts-1",
      voice: "alloy",
      input: textToConvert,
    });

    const speechFile = path.resolve(`./speech${podCount}.mp3`);
    const buffer = Buffer.from(await mp3.arrayBuffer());
    await fs.promises.writeFile(speechFile, buffer);

    res.sendFile(speechFile);
  } catch (error) {
    console.error('Error generating audio:', error);
    res.status(500).send('Error generating audio');
  }
});

app.listen(port, () => {
  console.log(`Server listening at http://localhost:${port}`);
});
